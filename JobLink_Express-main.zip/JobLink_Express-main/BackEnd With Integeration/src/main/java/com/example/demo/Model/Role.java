package com.example.demo.Model;

public enum Role {
    USER,
    ADMIN
}
