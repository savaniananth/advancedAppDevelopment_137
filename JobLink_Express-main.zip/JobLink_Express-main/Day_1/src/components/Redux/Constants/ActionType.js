export const ActionTypes = {
    SET_ROLE: "SET_ROLE",
  };