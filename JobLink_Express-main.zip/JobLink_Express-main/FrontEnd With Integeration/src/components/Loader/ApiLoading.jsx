import "../Loader/ApiLoading.css"
function ApiLoader() {
    return ( <>
    <div class="loader-container">
    <div class="loader">
    <div class="loader__bar"></div>
    <div class="loader__bar"></div>
    <div class="loader__bar"></div>
    <div class="loader__bar"></div>
    <div class="loader__bar"></div>
    <div class="loader__ball"></div>
    </div>
    </div>
    </> );
}

export default ApiLoader;