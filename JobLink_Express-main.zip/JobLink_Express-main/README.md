<h1>JOBLINK_EXPRESS</h1>
<h4>An Job Seeking Site</h4>
<h3>Problem Statement</h3>
In the current employment landscape, the process of job application and management often involves cumbersome procedures for both employers and job seekers. Employers face challenges in efficiently posting job listings and managing applications, while job seekers encounter difficulties in finding relevant opportunities and tracking the status of their applications. The lack of a centralized and user-friendly platform contributes to inefficiencies, data security concerns, and an overall suboptimal experience in the job application process.
<h3>Updates</h3>
<h4>Day_1</h4>
<ul>
  <li>Created Project Using template React in Vite</li>
  <li>Created Folder Structure Required For Projects</li>
  <li>Created Hello_World Functional Component</li>
</ul>
