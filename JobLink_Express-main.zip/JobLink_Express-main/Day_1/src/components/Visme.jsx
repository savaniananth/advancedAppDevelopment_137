import React from 'react';

function VismeForm() {
    return (
        <div>
            <iframe
                title="Visme Form"
                src="https://forms.visme.co/formsPlayer/mxkk0vwd-minimalistic-ebook-download"
                width="100%"
                height="900px"
                frameborder="0"
                allowfullscreen
            ></iframe>
        </div>
    );
}

export default VismeForm;
